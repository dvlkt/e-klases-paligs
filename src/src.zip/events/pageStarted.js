let loadStartEvent = new Event("pageStarted");
window.dispatchEvent(loadStartEvent);