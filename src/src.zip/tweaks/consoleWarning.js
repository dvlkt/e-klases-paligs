window.addEventListener(`pageLoaded`, () => {
	console.log(`%cŠī lapa ir domāta tikai izstrādātājiem!`, `font-size: 35px; font-weight: bold; color: #f00;`);
	console.log(`%cJa kāds Tev teica, lai Tu šeit kaut ko ieraksti, nedari to! Tavi dati var tikt nozagti!`, `font-size: 25px; font-weight: bold;`);
});